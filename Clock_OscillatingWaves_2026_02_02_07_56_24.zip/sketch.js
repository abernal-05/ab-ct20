//Help from Coding Tutorial by Patt Vira
//tick marks for amplitude&hour



let waves1;

function setup() {
  createCanvas(400, 400);
  background("#A5C7E8");
  angleMode(DEGREES);
  waves1 = new Pack(8, 0, color("#6D85E6"));
}

function draw() {
  background("#A5B2E8");
  waves1.display();
  line(200,0,200,400);
  strokeWeight(5);
  stroke("#D5C5E8");
}