class Pack {
  constructor(numWave, shift, color) {
    this.waves = [];
    this.numWave = numWave;
    this.shift = shift;
    this.color = color;
    
    for (let i=0; i<numWave; i++) {
      this.waves[i] = new Wave1(this.shift, this.color);
    }
  }
  
  display() {
    for (let i=0; i<this.numWave; i++) {
      this.waves[i].displayWave();
    line(400,0,400,800);
    stroke("#D5C5E8");
    }
  }
}